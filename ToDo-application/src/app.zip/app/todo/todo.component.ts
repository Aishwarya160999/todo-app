import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { todoService } from '../todo.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  todoForm!: FormGroup
  todo!: string[] | null;
  constructor(
    private todoservice: todoService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {

    this.todoForm = this.formBuilder.group({
      title: ['', [Validators.required]]
    });
    this.todo = this.todoservice.findAll();
  }
  add(): void {
    this.todoservice.add(this.todoForm.value.title);
    this.todo = this.todoservice.findAll();
  }
  delete(index: number): void {
    var result = confirm('are you sure?');
    if (result) {
      this.todoservice.remove(index);
      this.todo = this.todoservice.findAll();
    }
  }
}

